using System;

namespace baiTapClass
{
   partial class Program
   {
      public static void Main()
      {
         try
         {
            UserInformation user = new UserInformation();
            user.GetUserInformation();
            user.PrintUserInformation();
         }
         catch (Exception ex)
         {
            Console.WriteLine(ex.Message);
         }
         Console.ReadLine();
      }
    }
}
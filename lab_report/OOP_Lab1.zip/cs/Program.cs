using System;
using baiTapClass;

namespace baiTapClass
{
   class Program
   {
      UserInformation user1 = new UserInformation("Khoa Hoc Tu Nhien", 28, 21200201);
      UserInformation user2 = new UserInformation("Xa Hoi Nhan Van", 32, 21200202);
      UserInformation user3 = new UserInformation("Cong Nghe Thong Tin", 18, 21200203);
      List<UserInformation> users = new List<UserInformation>() { user1, user2, user3 };
      Console.WriteLine("List user sorted by Age:");
      List<UserInformation> sortedUsersByAge = users.OrderBy(x => x.userAge).ToList();
      Console.WriteLine(String.Join(Environment.NewLine, sortedUsersByAge));
      Console.WriteLine("\n\nList user sorted by ID:");
      List<UserInformation> sortedUsersByID = users.OrderByDescending(x => x.userID).ToList();
      Console.WriteLine(String.Join(Environment.NewLine, sortedUsersByID));
      }
   }
}
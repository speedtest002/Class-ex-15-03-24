public static void main()
{
    try
    {
        BankAccount alexAccount = null;
        GetUserBankAccountInformation(out alexAccount);
        Console.WriteLine("Please type in your password to show current balance");
        alexAccount.VerifyPassword(Console.ReadLine());
        Console.WriteLine($"{alexAccount.CalculateInterestMoney()}");
        Console.WriteLine($"interest rate: {BankAccount.InterestRate}");
    }
    catch (AccessDeniedException)
    {
       Console.WriteLine("Access denied!");
    }
    catch (OverflowException ex)
    {
       Console.WriteLine(ex.StackTrace);
    }
    Console.ReadLine();
}

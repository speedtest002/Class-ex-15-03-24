public static void GetUserBankAccountInformation(out BankAccount account)
{
   Console.WriteLine("Please type in your name");
   string userName = Console.ReadLine();
   Console.WriteLine("Please type in your age");
   int userAge = int.Parse(Console.ReadLine());
   Console.WriteLine("Please type in your ID");
   uint userID = uint.Parse(Console.ReadLine());
   Console.WriteLine("Please type in your balance");
   double balance = double.Parse(Console.ReadLine());
   Console.WriteLine("Please type in your password");
   string password = Console.ReadLine();
   account = new BankAccount(userName, userAge, userID, balance, password);
   //var account = new BankAccount(string userName, int userAge, uint userID, double Balance, string Password);
}
public static void main()
{
   UserInformation[] users = new UserInformation[6]
   {
      new Employee("Employee 0", 23, 1000, 10_000_000),
      new Employee("Employee 1", 21, 1001, 11_000_000),
      new Manager ("Manager 2", 27, 1012, 12_000_000),
      new Manager ("Manager 3", 24, 1013, 18_000_000),
      new Director("Director 4", 32, 1024, 13_000_000),
      new Director("Director 5", 29, 1025, 14_000_000),
   };
   foreach (var user in users)
   {
      Console.WriteLine($"{user.UserName}: {user.GetSalary()}\n");
   }
   Console.WriteLine("_______ HIGH TO LOW _________");
   for (int i = 0; i < 6; i++)
   {
      for (int j = 0; j < 6 - i - 1; j++)
      {
         if (users[j].GetSalary() < users[j + 1].GetSalary())
         {
            var temp = users[j];
            users[j] = users[j + 1];
            users[j + 1] = temp;
         }
      }
   }
   foreach (var user in users)
   {
      Console.WriteLine($"{user.UserName}: {user.GetSalary()}\n");
   }

   Console.WriteLine("_______ LOW TO HIGH _________");
   for (int i = 0; i < 6; i++)
   {
      for (int j = 0; j < 6 - i - 1; j++)
      {
         if (users[j].GetSalary() > users[j + 1].GetSalary())
         {
            var temp = users[j];
            users[j] = users[j + 1];
            users[j + 1] = temp;
         }
      }
   }
   foreach (var user in users)
   {
      Console.WriteLine($"{user.UserName}: {user.GetSalary()}\n");
   }
}

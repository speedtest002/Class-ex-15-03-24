internal class AccessDeniedException : ApplicationException
{
   public AccessDeniedException() { }
   public AccessDeniedException(string message) : base(message) { }

}

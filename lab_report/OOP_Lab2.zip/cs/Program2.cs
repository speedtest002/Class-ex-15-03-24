using System;

namespace classLab
{
   class Program
   {
        BankAccount alexAccount = new BankAccount("alex", 20, 1111, 1000, "alex123");
        //Nhap dung password
        Console.WriteLine("Please enter your password");
        alexAccount.VerifyPassword(Console.ReadLine());
        Console.WriteLine(alexAccount.CalculateInterestMoney());
        //Nhap sai password
        Console.WriteLine("Please enter your password");
        alexAccount.VerifyPassword(Console.ReadLine());
        Console.WriteLine(alexAccount.CalculateInterestMoney());
   }
}